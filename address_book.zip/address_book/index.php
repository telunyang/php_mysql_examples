<!DOCTYPYE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>我的 PHP 程式</title>
</head>
<body>
<form name="myForm" method="post" action="./login.php">
帳號: <input type="text" name="username" value="" /><br />
密碼: <input type="password" name="pwd" value="" /><br />
<input type="submit" value="登入" />
</form>
</body>
</html>